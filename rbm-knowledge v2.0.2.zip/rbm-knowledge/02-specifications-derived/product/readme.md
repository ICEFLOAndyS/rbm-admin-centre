# RBM Product Starter Pack (v2.02)

Generated: 2025-12-28 15:03:59

## Purpose
Provides a baseline set of product-level documents for the Runbook Management (RBM) solution.

## Placement
Copy into:
`02-specifications-derived/product/`

## Usage
- Defines stable product intent and constraints
- Referenced by all features
- Must not reference specific features
