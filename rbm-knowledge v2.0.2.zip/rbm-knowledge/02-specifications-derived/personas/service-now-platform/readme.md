# Technology-Platform

## Personas in this category

- **ServiceNow Platform Owner** — `ServiceNow-Platform-Owner.md`
- **ServiceNow Architect** — `ServiceNow-Architect.md`
- **CIO / CTO** — `CIO-CTO.md`
- **CISO / Security Architect** — `CISO-Security-Architect.md`
- **IT Service Delivery Manager** — `IT-Service-Delivery-Manager.md`
