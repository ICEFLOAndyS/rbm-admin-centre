# Gate 0 – Scope Definition

## Status
APPROVED

## Feature
content-packs

## In Scope
-

## Out of Scope
-
