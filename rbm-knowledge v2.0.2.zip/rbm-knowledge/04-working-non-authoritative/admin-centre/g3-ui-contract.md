# Gate 3 – UI Contract

## Status
APPROVED

## Approved RBM Components
- RBMDataGrid
- RBMSidePanel

## Forbidden
- sn-datagrid
- now-side-panel
- UI Builder
