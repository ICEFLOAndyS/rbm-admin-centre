# Evidence and Audit Standard (v2.02)

Generated: 2025-12-28 14:49:30

Every feature must produce evidence sufficient to:
- demonstrate compliance
- support audit and review
- enable traceability

Evidence requirements are defined per feature.
