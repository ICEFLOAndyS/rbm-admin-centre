# Decision Management Standard (v2.02)

Generated: 2025-12-28 14:49:30

All material design or governance decisions MUST:
- be recorded in a feature decision log
- include rationale and approver
- be auditable

Undocumented decisions are invalid.
