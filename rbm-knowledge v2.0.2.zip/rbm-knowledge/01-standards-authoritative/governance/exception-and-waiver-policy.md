# Exception and Waiver Policy (v2.02)

Generated: 2025-12-28 14:49:30

Exceptions to standards:
- are discouraged
- must be explicit
- must be approved
- must be time-bound

No silent deviations permitted.
