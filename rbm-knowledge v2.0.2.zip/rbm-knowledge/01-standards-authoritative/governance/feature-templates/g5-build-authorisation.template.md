# Gate 5 — Build Authorisation

**Feature:** {{FEATURE_NAME}}  
**Knowledge Version:** {{KNOWLEDGE_VERSION}}  
**Created on:** {{CREATED_ON}}  
**Created by:** {{CREATED_BY}}

## Status
DRAFT

## Approved inputs (must be APPROVED)
- g1-data-architecture.md
- g2-security-acl.md
- g3-ui-contract.md
- g4-api-contract.md

## Pre-flight evidence
- preflight-report.md

## Build Authorised
NO

## Notes / limitations
-

## Approval
- Approved by: {{APPROVED_BY}}
- Approved on: {{APPROVED_ON}}
- Approval ref: {{APPROVAL_REF}}

