# Approvals Register

**Feature:** {{FEATURE_NAME}}  
**Knowledge Version:** {{KNOWLEDGE_VERSION}}  
**Created on:** {{CREATED_ON}}  
**Created by:** {{CREATED_BY}}

## Gate approvals
| Gate | File | Status | Approved by | Approved on | Approval ref |
|---|---|---|---|---|---|
| G0 | g0-scope.md | DRAFT |  |  |  |
| G1 | g1-data-architecture.md | DRAFT |  |  |  |
| G2 | g2-security-acl.md | DRAFT |  |  |  |
| G3 | g3-ui-contract.md | DRAFT |  |  |  |
| G4 | g4-api-contract.md | DRAFT |  |  |  |
| G5 | g5-build-authorisation.md | DRAFT |  |  |  |
| PF | preflight-report.md | DRAFT |  |  |  |
