# Gate 4 — API & Server Contract

**Feature:** {{FEATURE_NAME}}  
**Knowledge Version:** {{KNOWLEDGE_VERSION}}  
**Created on:** {{CREATED_ON}}  
**Created by:** {{CREATED_BY}}

## Status
DRAFT

## APIs / Script Includes (authoritative)
| Name | Type | Purpose | Inputs | Outputs | Notes |
|---|---|---|---|---|---|

## Validation rules (authoritative)
-

## Data access (mandatory)
- Server-side filtering/sorting/pagination as applicable
- No business logic in UI
- Audit logging where required

## Approval
- Approved by: {{APPROVED_BY}}
- Approved on: {{APPROVED_ON}}
- Approval ref: {{APPROVAL_REF}}
