# Pre-flight Report

**Feature:** {{FEATURE_NAME}}  
**Knowledge Version:** {{KNOWLEDGE_VERSION}}  
**Created on:** {{CREATED_ON}}  
**Created by:** {{CREATED_BY}}

## Status
DRAFT

## Validator run
- Command:
- Result: PASS / FAIL
- Timestamp:
- Validator version:

## Findings
-

## Evidence
- Link / artefact reference:

## Approval
- Approved by: {{APPROVED_BY}}
- Approved on: {{APPROVED_ON}}
- Approval ref: {{APPROVAL_REF}}

