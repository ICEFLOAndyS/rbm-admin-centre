# Gate 1 — Data & Architecture Contract

**Feature:** {{FEATURE_NAME}}  
**Knowledge Version:** {{KNOWLEDGE_VERSION}}  
**Created on:** {{CREATED_ON}}  
**Created by:** {{CREATED_BY}}

## Status
DRAFT

## Tables (authoritative)
| Table | Purpose | Notes |
|---|---|---|

## Fields (authoritative)
| Table | Field | Type | Mandatory | Default | Notes |
|---|---|---:|:---:|---|---|

## Relationships & constraints (authoritative)
-

## Prohibitions (non-negotiable)
- No additional tables beyond those listed above
- No additional fields beyond those listed above
- No domain separation
- No client table
- Any ambiguity must be resolved in this artefact (do not defer to build)

## Approval
- Approved by: {{APPROVED_BY}}
- Approved on: {{APPROVED_ON}}
- Approval ref: {{APPROVAL_REF}}

