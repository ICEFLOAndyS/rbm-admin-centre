# Agent Index – Foldered Standards + References Pack

Each agent has its own folder containing:
- agent definition markdown
- REFERENCES.md (internal RBM design system refs + external ServiceNow deep links)

- Ai_Prompt_Engineer_Agent/
- Chatgpt_Orchestrator_Agent/
- Dashboard_Designer_Agent/
- Flow_Designer_Agent/
- Front_End_Developer_Agent/
- Ms_Teams_Integration_Agent/
- Persona_User_Journeys_Agent/
- Platform_Developer_Agent/
- Quality_Engineer_Agent/
- Security_Expert_Agent/
- Servicenow_Architect_Agent/
- Ux_Ui_Designer_Agent/
