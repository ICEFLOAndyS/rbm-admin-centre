# PROMPT 5 — Audit UI

## Scope Declaration (MANDATORY)
- ORG_CODE = {{ORG_CODE}}
- SCOPE_TAG = {{SCOPE_TAG}}
- APP_SCOPE = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}
- APP_PREFIX = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}


Inputs:
- 02-user-journeys-admin-center.md

Deliver:
- Audit list/search
- Audit detail view (immutable)