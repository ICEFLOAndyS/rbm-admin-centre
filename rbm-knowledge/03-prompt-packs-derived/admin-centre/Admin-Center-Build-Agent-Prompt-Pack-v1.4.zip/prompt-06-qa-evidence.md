# PROMPT 6 — QA & Evidence

## Scope Declaration (MANDATORY)
- ORG_CODE = {{ORG_CODE}}
- SCOPE_TAG = {{SCOPE_TAG}}
- APP_SCOPE = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}
- APP_PREFIX = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}


Inputs:
- 07-qa-admin-center.md
- 04-security-admin-center.md

Deliver:
- Automated tests
- Evidence checklist outputs