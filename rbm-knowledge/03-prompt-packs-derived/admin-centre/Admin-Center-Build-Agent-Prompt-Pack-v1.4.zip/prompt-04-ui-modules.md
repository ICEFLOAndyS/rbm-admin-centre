# PROMPT 4 — UI Modules (Feature Flags + System Settings)

## Scope Declaration (MANDATORY)
- ORG_CODE = {{ORG_CODE}}
- SCOPE_TAG = {{SCOPE_TAG}}
- APP_SCOPE = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}
- APP_PREFIX = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}


Inputs:
- 02-user-journeys-admin-center.md
- 06-frontend-dev-admin-center.md

Deliver:
- List/detail/edit modules
- Server-side paging/filter/sort
- Confirmation modals