# PROMPT 3 — UI Shell + Navigation

## Scope Declaration (MANDATORY)
- ORG_CODE = {{ORG_CODE}}
- SCOPE_TAG = {{SCOPE_TAG}}
- APP_SCOPE = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}
- APP_PREFIX = x_{{ORG_CODE}}_rbm_{{SCOPE_TAG}}


Authority:
- React + TS only
- RBM reference components first

Inputs:
- 01-personas-admin-center.md

Deliver:
- Admin Center shell
- Section navigation (Feature Flags, System Settings, Audit)